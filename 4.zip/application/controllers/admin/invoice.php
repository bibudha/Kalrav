<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class invoice extends CI_Controller
{
function __construct()
		{
		parent::__construct();
		$this->load->model("admin/invoice_model");
          //      $this->load->model("admin/login_model");
		  $this->load->model("admin/product_model");
		}


// function for showing bill choice 
public function index()
{
	 if($this->session->userdata('logged_in'))
			{
			$data['user_data'] = $this->session->userdata('logged_in');
			              
			$this->load->view('admin/header_view',$data);
			$this->load->view('admin/all_bill_view');
			$this->load->view('admin/footer_view');
			
			}
	    else
			{
		   	redirect('login', 'refresh');
			}
		
		
	
}  	
//function for checking and showing Bill view 
public function s_bill()
{

	 if($this->session->userdata('logged_in'))
			{
				
			$data['get_products']= $this->product_model->get_all_products();
			$data['user_data'] = $this->session->userdata('logged_in');
			              
			$this->load->view('admin/header_view',$data);
			$this->load->view('admin/direct_bill_view');
			$this->load->view('admin/footer_view');
			
			}
	    else
			{
		   	redirect('login', 'refresh');
			}
		
		
}  	

//function for Showing Information .. of Bill step 
public function step_bill()
{
$a=$this->security->xss_clean($this->input->post('option'));
				if($a==0){
	 if($this->session->userdata('logged_in'))
			{
				$data['user_data'] = $this->session->userdata('logged_in');
				$data['a']=$a;
			$this->load->view('admin/header_view',$data);
			$this->load->view('admin/bill_step_view');
			$this->load->view('admin/footer_view');
			
			}
	    else
			{
		   	redirect('login', 'refresh');
			}
		
		}
	
}  	


public function chalan_view()
{
$a=$this->security->xss_clean($this->input->post('option'));

	 if($this->session->userdata('logged_in'))
			{
				$data['user_data'] = $this->session->userdata('logged_in');
				if($a==0)
				{
				$data['a']="Direct Billing";
				$data['id']=$a;
				}
				else
				{$data['a']="Order  Billing";
				$data['id']=$a;
				}
						              
			$this->load->view('admin/header_view',$data);
			$this->load->view('admin/chalan_view');
			$this->load->view('admin/footer_view');
			
			}
	    else
			{
		   	redirect('login', 'refresh');
			}
		
		
}  	


// function for ajax
public function get_chalan_no()
{
 if($this->session->userdata('logged_in'))
			{
			$res= $this->invoice_model->ch_no();
			print_r($res);
			
			//$str="";
			if($res)
				{			
					//$str= $res;
					
					echo $res;
					
					}
					else
					{
					$str="NA";
					//echo $str;
					}
				
			
			}
			 else
			{
				
			}
		
	
	
	}
	
	// function for inserting chalan data into chalan table 
	public function bill_details()
		{
			 if($this->session->userdata('logged_in'))
			{
			$a=$this->security->xss_clean($this->input->post('bill_type'));
			$b=$this->security->xss_clean($this->input->post('ch_no'));
			$c=$this->security->xss_clean($this->input->post('chalan_date'));
			$d=$this->security->xss_clean($this->input->post('client_name'));
			$e=$this->security->xss_clean($this->input->post('paking_slip_no'));
			
			//$f=$this->input->post('particular');
			//print_r($f);
			//exit();
			$get_arr=array('0'=>$b,
							'1'=>$a,
						   '2'=>$d,
							'3'=>$c,
							'4'=>$e	);
			
		//	print_r($get_arr);
				$ch_id=$this->invoice_model->chalan_data($get_arr);
				//print_r($ch_id);
				//exit;
				
				$arr_p=(array_slice($this->input->post('particular'),0,-1));
				$j=count($arr_p);
				//print_r($j);
				//exit();
				$arr_size=(array_slice($this->input->post('size'),0,-1));
				$arr_quantity=(array_slice($this->input->post('quantity'),0,-1));
				
				$product_data=array();
				
				for($i=0;$i<$j;$i++)
			{
				for($k=1;$k<=3;$k++)
				{
					
					if($k==1)
					{
					$product_data[$i][$k]=$arr_p[$i];
					}
					if($k==2)
					{
					$product_data[$i][$k]=$arr_size[$i];
					}
					if($k==3)
					{
					$product_data[$i][$k]=$arr_quantity[$i];
					}
				
				}
			}
				
					$res=$this->invoice_model->create_itp($product_data,$ch_id,$j);
				
				//------------
				
				if($res)
				{
				//$this->session->set_flashdata('success_msg', 'Insert Successfully');
				redirect("admin/invoice/bill_view/$b",'refresh');

				}
				else
				{
				//$this->session->set_flashdata('error_msg', 'Sorry  Insertation Failed ');
				redirect("admin/product/add_product",'refresh');
				}	
			}
			
		}	
	


//--- fucnction for bill_view--
public function bill_view($a)
{
//$a=$this->security->xss_clean($this->input->post('option'));

	 if($this->session->userdata('logged_in'))
			{
				$data['user_data'] = $this->session->userdata('logged_in');
				$data['chalan_data'] =	$this->invoice_model->get_all_chalan($a);	
				$data['product_data'] =	$this->invoice_model->get_all_itp($a);				              
			$this->load->view('admin/header_view',$data);
			$this->load->view('admin/bill_view');
			$this->load->view('admin/footer_view');
			
			}
	    else
			{
		   	redirect('login', 'refresh');
			}
		
		
}  	



}