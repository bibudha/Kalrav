<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class invoice_model extends CI_Model
{



	
	// function for all category for ajax
	
		public function ch_no()
	{
				$this->db->select('max(ch_no) as ch_no');
				//$this->db->where('p_id',$id);
			$this->db->from('tbl_chalan');
			//$this->db->join('tbl_units unt', 'unt.u_id = prd.u_id');
						$query=$this->db->get();
			//echo $this->db->last_query();
		$row=$query->result();
		//echo $this->db->last_query();
			//	print_r($query->result())	;
				//print_r( $row[0]->ch_no);
				echo (int)$row[0]->ch_no;
				
			
	
	}
	
	
	public function chalan_data($get_arr)
	{
	
	$data_insert = array( 'ch_no'=>$get_arr[0],
							'bill_type'=>$get_arr[1],
							'client_name'=>$get_arr[2],
							'ch_date'=>$get_arr[3],
							'pack_slip_no'=>$get_arr[4],
						   	);
				
			if($this->db->insert('tbl_chalan',$data_insert))
				{
		$insert_id = $get_arr[0];
		//echo "sss".$insert_id;
		//exit;
			
			return $insert_id;
				
			//return true;
				}
			else
			{ 
			return false;
			}
	}
	
	
	
	//----------------
	// for function for insert data entery on order to product table
	
	
	public function create_itp($get_arr,$ch_id,$j)
	{

				
	$data_chalan=array();
	$data_chalan['ch_no']=$ch_id;
	for($i=0;$i<$j;$i++)
	{
		for($k=1;$k<=3;$k++)
			{		
				if($k==1)
				{
				$data_chalan['particulars']=$get_arr[$i][$k];
				}
				if($k==2)
				{
				$data_chalan['size']=$get_arr[$i][$k];
				}
				if($k==3)
				{
				$data_chalan['quantity']=$get_arr[$i][$k];
				}
	
			}
			
			
		$res=$this->db->insert('tbl_invoice_to_product',$data_chalan);	
		}	
			
		if($res=true)
		{
		return true;
		}
		else
		{
		return false;
		}

	}
		
			// function for gets all units 	
				
	public function get_all_chalan($ch_no)
	{
			$this->db->select('*');
			$this->db->where('ch_no',$ch_no);
			$this->db->from('tbl_chalan');
			$query=$this->db->get();
			$row=$query->result();
						
				return $row;
			
	
	}
	
			// function for gets all units 	
				
	public function get_all_itp($ch_no)
	{
			$this->db->select('*');
			$this->db->where('ch_no',$ch_no);
			$this->db->from('tbl_invoice_to_product');
			$query=$this->db->get();
			$row=$query->result();
						
				return $row;
			
	
	}
	
		
	
	
	
}