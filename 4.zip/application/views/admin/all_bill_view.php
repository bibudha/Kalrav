


 <div class="right_content">   
 <form action="<?php echo base_url();?>admin/invoice/step_bill" method="post">
<table>
<tr><td> Option</td>
<td><select name="option" >

<option value="0">Direct Billing </option>
<option value="1">Previously Order Billing</option></select>
</td>
</tr>
<tr><td><input type="submit" name="submit" value="Go" /></td></tr>
</table>
</form>
</div>
