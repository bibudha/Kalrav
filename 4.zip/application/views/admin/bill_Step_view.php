<div class="right_content">   
  <h1> Bill Steps Information</h1>
  <form action="<?php echo base_url();?>admin/invoice/chalan_view" method="post">
 <input type="hidden" name="option" value="<?php echo $a ?>" />
  <p> Hello Admin ... Here Some Step for BILLING ..</p> <br />
<br />
<h2> Step 1 :</h2><p> First Create Chalan . </p><br />
<h2> Step 2:</h2><p>  Then Create Bill . </p><br />
<h2> Step 3 :</h2><p> Then Print Bill  . </p><br>

	
 <input type="submit" name="submit" value=" Go For Chalan ..." />
 
 </form> 
</div>