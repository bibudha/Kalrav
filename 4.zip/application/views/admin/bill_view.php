<div class="right_content">   
<h1>Bill </h1>

<script type="text/javascript">

$(document).ready(function(){


});
function calc()
{
alert('yep');
if($('#price').val()=="NULL" )
{
alert("Enter Price first");
} 
else
{
alert($('#price').val())
}
}

</script>

<form action="<?php echo base_url();?>admin/invoice/bill_details" method="post">


<table width="507" border="0" class="sarni">
<?php  foreach($chalan_data  as $chalan) { ?>
    <td width="46">Chalan No </td>
    <td width="146"><input type="text" name="ch_no" readonly="" value="<?php echo $chalan->ch_no; ?>" class="ch_no" ></td>
    <td width="126"> Bill date </td>
    <td width="171"><input type="date" name="date_date"   value="" /></td>
  </tr>
  <tr>
    <td>Client Name </td>
    <td><input type="text" name="client_name" placeholder="Client Name" readonly="" value="<?php echo $chalan->client_name; ?>"></td>
	 <td>Packing Slip Number </td>
    <td><input type="text" name="paking_slip_no"  readonly="" value="<?php echo $chalan->pack_slip_no; ?>"/></td>
    </tr> <?php } ?>
<br>

<tr><td colspan="4"><br>
<h2>  Details </h2></td></tr>
<br>
<?php $i=0;
foreach($product_data as $product) { ?>
<tr class="clone"><td>Particulars</td><td><input type="text" name="particular[]" value="<?php echo $product->particulars; ?>"></td>
<td>&nbsp;&nbsp;&nbsp; Size</td>
<td><input type="text" name="size[]" placeholder="Size"   value="<?php echo $product->size; ?>" required/></td></<br />
<td>Quantity</td>
<td><input type="text" name="quantity[]"  id="quantity" placeholder="Quantity"   required value="<?php echo $product->quantity; ?>"/></td><br>

<td>price</td>
<td><input type="text" name="price" placeholder="price"  class="price" id="price " value=""/></td>
<?php } ?>
<td></td>
	</tr>
	 <tr>
  <td align="center"></td></tr>
  <tr><td><input type="button" name="cal" value="cal" onClick="calc()" ></td>
    <td colspan="4"><input type="submit" name="submit" value="Submit"></td>
    
	</tr>
</table>
</form>
</div>