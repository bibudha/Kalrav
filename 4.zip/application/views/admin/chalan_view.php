<div class="right_content">   
<h1>Chalan </h1>
<script type="text/javascript">

$(document).ready(function(){

$('.sarni tr.clone').clone(true).removeClass('clone').addClass('clone2').insertAfter('.clone').hide();
	$('.addmore').click(function(){$('.sarni').find('.clone2').clone(true).removeClass('clone2').addClass('clone').insertBefore('.clone2').show();});
	$('.remove').click(function(){$(this).closest("tr").remove();
	 var a= $(this).closest('tr');
	//var b= a.find('.sub').val();	
	// var c= $('.total').val()
	// $('.total').val(c-b);}); 
	//var a=$('.clone').length;
	});
	var u_rl="<?php echo base_url(); ?>"+"admin/invoice/get_chalan_no";
	
				$.ajax({
							url:u_rl,
							type:'GET',
							cache: false,
							data:"",
							success: function(html)
							{ 
							if(html)
								{
								//alert(typeof(html));
								var chalan_no= parseInt(html)+1;
								//alert(chalan_no);
								
								$(".ch_no").val(chalan_no);
								}
							else
								{
								alert('NO Units');
								}
							
							}
						
						
						})

	
	
	});
	</script>
<form action="<?php echo base_url();?>admin/invoice/bill_details" method="post">

<table width="507" border="0" class="sarni">
<tr><td>Billing</td><td><input type="text" disabled="disabled" value=" <?php echo $a; ?> "/></td>
<td><input type="hidden" value=" <?php echo $id; ?> " name="bill_type"/></td></tr>
  <tr>
    <td width="46">Chalan No </td>
    <td width="146"><input type="text" name="ch_no" readonly="" value="" class="ch_no" ></td>
    <td width="126"> Chalan date </td>
    <td width="171"><input type="date" name="chalan_date" value="" /></td>
  </tr>
  <tr>
    <td>Client Name </td>
    <td><input type="text" name="client_name" placeholder="Client Name" value=""></td>
	 <td>Packing Slip Number </td>
    <td><input type="text" name="paking_slip_no"  value=""/></td>
    </tr>
<br>
<tr><td colspan="4"><h2> Packing Slip Details </h2></td></tr>
<br>
<tr class="clone"><td>Particulars</td><td><input type="text" name="particular[]" value=""></td>
<td>&nbsp;&nbsp;&nbsp; Size</td>
<td><input type="text" name="size[]" placeholder="Size" /></td><br />
<td>Quantity</td><td><input type="text" name="quantity[]" placeholder="Quantity" /></td></<br />

<td><a class="remove" title="Remove">&#10006;</a><hr style="visibility:hidden" /></td>
	</tr>
	 <tr>
  <td align="center"><a class="addmore" title="Add more">&#10010;</a></td></tr>
  <tr>
    <td colspan="4"><input type="submit" name="submit" value="Submit"></td>
    
	</tr>
</table>
</form>
</div>