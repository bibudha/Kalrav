
 <div class="right_content">   
 <h1>Edit Products</h1>
 
<form action="<?php echo base_url();?>admin/product/insert_edit_data" method="post">
 <table width="249" border="0"  id="rounded-corner">
  <tr><?php foreach($get_product  as $products) { ?>
    <td width="95">Product Id</td>
    <td width="144"><input type="hidden" name="p_id" value="<?php echo $products->p_id ?>" required><?php echo $products->p_id ?></td>
  </tr>
  <tr>
    <td>Product Name</td>
    <td><input type="text" name="p_name" value="<?php echo $products->p_name ?>" required ></td>
  </tr>
  <tr>
    <td>Color</td>
    <td><input type="text" name="p_color" value="<?php echo $products->p_color ?>" required></td>
  </tr>
  <tr>
    <td>Size</td>
    <td><input type="text" name="p_size" value="<?php echo $products->p_size ?>" required></td>
  </tr>
  <tr>
    <td>Unit Name</td>
    <td><select name="u_id" required>
		<?php 
		$sel="";
		foreach($get_units  as $units) { 
		if($units->u_id == $product->u_id)
		{
		$sel="selected";
		}
		?>
  <option <?php echo $sel ;?> value="<?php echo $units->u_id ?>"><?php echo $units->u_name ?></option>
  <?php } ?>
 	</select></td>
  </tr> <?php } ?>
  <tr>
    <td>Quantity</td>
    <td><input type="text" name="p_quantity" value="<?php echo $products->p_quantity ?>" required></td>
  </tr>
  <tr>
    <td>Price</td>
    <td><input type="text" name="p_price" value="<?php echo $products->p_price ?>" required></td>
  </tr>
  
  
  <tr>
    <td><input type="submit" name="submit" value="Submit"></td>
    <td><input type="reset" name="reset" value="Cancel"></td>
  </tr>
</table>
 </form>


</div>
