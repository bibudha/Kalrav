<html>
 <div class="right_content">   

<h1>Add Group</h1>
<form action="<?php echo base_url();?>admin/group/get_data" method="post">
<table>
 <tr><td>Group Name</td>
 	<td><input type="text" name="group_name" value=""></td>
	</tr>
<tr><td><input type="submit" name="submit" value="submit"></td>
</tr></table>
</form>
</div>

</html>
