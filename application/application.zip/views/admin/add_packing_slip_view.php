<script type="text/javascript">
 jQuery(document).ready(function(){
  jQuery('#de_date').datepicker();
  jQuery('.sarninew tr.clone').clone(true).removeClass('clone').addClass('clone2').insertAfter('.clone').hide();
	$('.addmore').click(function(){$('.sarninew').find('.clone2').clone(true).removeClass('clone2').addClass('clone').insertBefore('.clone2').show();});
	$('.remove').click(function(){$(this).closest("tr").remove()});
	 var a= $(this).closest('tr');
  


var u_rl="<?php echo base_url(); ?>"+"admin/invoice/packing_no";
	
				jQuery.ajax({
							url:u_rl,
							type:'GET',
							cache: false,
							data:"",
							success: function(html)
							{ 
							if(html)
								{
								//alert(html);
								var chalan_no= parseInt(html)+1;
								//alert('y');
							//	alert(chalan_no);
								
								$(".pslip_no").val(chalan_no);
								}
							else
								{
								alert('NO Units');
								}
							
							}						
						
						});
                                                
                       jQuery("input.no").blur(function(){
                           
			var tr_obj=$(this).closest('tr');
                        var qty  = tr_obj.find('.quantity').val();
                        var copy = tr_obj.find('.no').val();						                                          
                       
                        var c = parseFloat($(".final_quantity").val()) ;
                                         
                        var b = parseFloat(qty * copy);                      
                        var c  = c + b;
                                          
                       jQuery("input.total_quantity").val(c);
                        jQuery(".final_quantity").val(c);
                        //alert(total);
                      });
					  
				$('.dr').hide();
				$('.direct').click(function(){
				$('.or_n').toggle();
				$('.dr').toggle();
				});
					  
					  
 
 });
</script>
<div class="right_content">   
 <h1>Packing Slip</h1>
 <?php 
 //print_r($get_units);
 //print_r($get_units1); ?>
<form action="<?php echo base_url();?>admin/invoice/get_data" method="post" >
<table width="249" border="0"  id="rounded-corner" class="sarninew">
<!--<tr><td>Direct Billing </td> <td><input type="checkbox" name="direct" value="1" class="direct" /></td></tr>
	<tr>-->
	<tr>
    <td>Order No.</td>
    <td class="or_n"><select name="or_no" required>
	<option >Please Select</option>
	<?php foreach($or_no  as $order) { ?>
  <option value="<?php echo $order->id ?>"><?php echo $order->no ?></option>
  <?php } ?>
 	</select></td>
	<!--<td class="dr" ><input type="text" name="or_n" value=" " /></td>-->
  </tr>
   <tr>
    <td>Packing Slip No:</td>
    <td><input type="text" name="pslip_no" value=""  class="pslip_no" readonly="" ></td>
  </tr>
  <!-- <tr>
    <td>Client Name</td>
    <td><input type="text" name="cname" value="" required ></td>
  </tr>-->
    <tr>
    <td>Date:</td>
     <td><input type="text" name="packing_date" readonly="" class="de_date" value=""  id="de_date"/></td>
  </tr>
   <tr>
    <td >Products</td>
    <td><select name="product_id" required>
	<option value="0">Please Select</option>
	<?php foreach($get_products  as $product) { ?>
  <option value="<?php echo $product->p_id ?>"><?php echo $product->p_name ?></option>
  <?php } ?>
 	</select></td>
  </tr>
  <tr>
    <td>Product Description:</td>
    <td><input type="text" name="descpt" value="" required ></td>
  </tr>
	<tr>
    <td>Product Color:</td>
    <td><input type="text" name="pcolor" value="" required ></td>
  </tr>
	<tr>
    <td>Product Design:</td>
    <td><input type="text" name="pdesign" value="" required ></td>
  </tr>
  <tr>
    <td>Total Quantity:</td>
    <td><input type="text" name="total_quantity" class="total_quantity" value="" required >
        <input type="hidden" name="final_quantity" class="final_quantity" value="0" >
    </td>
  </tr>
	

<tr class="clone">
    <td>Quantity In Paking Slip:<br /><br />

 No of coyies </td>
    <td><input type="text" name="quantity[]" value="" class="quantity" ><br /><br />

<input type="text" name="no[]" value="" class="no" /></td>
<td><a class="remove" title="Remove">&#10006;</a><hr style="visibility:hidden" /></td>  </tr>
  
  <tr>
<td align="center"><a class="addmore" title="Add more">&#10010;</a></td>
    <td><input type="submit" name="submit" value="Submit"></td>
    <td><input type="reset" name="reset" value="Cancel"></td>
  </tr>

 <tr>
 
 
 
 </table>
</form>

</div>

