<html>
 <div class="right_content">   

<h1>Add Units</h1>
<form action="<?php echo base_url();?>admin/units/get_data" method="post">
<table>
 <tr><td>Unit Name</td>
 	<td><input type="text" name="u_name" value=""></td>
	</tr>
<tr><td><input type="submit" name="submit" value="submit"></td>
</tr></table>
</form>
</div>

</html>